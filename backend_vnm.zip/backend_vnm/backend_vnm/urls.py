from django.contrib import admin
from django.urls import path, include
from django.http import HttpResponse

# Simple welcome view
def home(request):
    return HttpResponse("Welcome to the VNM Hitech Solutions Backend API!")

urlpatterns = [
    path('', home),  # This handles the root URL (http://localhost:8000/)
    path('admin/', admin.site.urls),
    path('api/careers/', include('careers.urls')),
    path('api/courses/', include('courses.urls')),
    path('api/contact/', include('contact.urls')),
]

# Media configuration for development
from django.conf import settings
from django.conf.urls.static import static
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)