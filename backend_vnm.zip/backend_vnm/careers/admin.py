from django.contrib import admin
from .models import JobListing, JobApplication

admin.site.register(JobListing)
admin.site.register(JobApplication)