from django.db import models

class JobListing(models.Model):
    title = models.CharField(max_length=200) # e.g., "MERN Stack Developer"
    description = models.TextField()
    type = models.CharField(max_length=100, default="Full-time")
    compensation = models.CharField(max_length=100, default="Not Disclosed")
    # Storing skills as a JSON list e.g. ["React", "Node"]
    skills = models.JSONField(default=list) 
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class JobApplication(models.Model):
    name = models.CharField(max_length=200)
    email = models.EmailField()
    mobile = models.CharField(max_length=20)
    location = models.CharField(max_length=200)
    position_applied = models.CharField(max_length=200) 
    resume_link = models.URLField() # Matches your frontend "resumeLink"
    message = models.TextField(blank=True)
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.position_applied}"