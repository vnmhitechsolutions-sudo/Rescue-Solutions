from django.urls import path
from .views import JobListView, JobApplicationView

urlpatterns = [
    path('jobs/', JobListView.as_view()),       # GET: List jobs
    path('apply/', JobApplicationView.as_view()), # POST: Submit application
]