from rest_framework import generics
from .models import JobListing, JobApplication
from .serializers import JobListingSerializer, JobApplicationSerializer

class JobListView(generics.ListAPIView):
    queryset = JobListing.objects.all()
    serializer_class = JobListingSerializer

class JobApplicationView(generics.CreateAPIView):
    queryset = JobApplication.objects.all()
    serializer_class = JobApplicationSerializer