from django.contrib import admin
from .models import ContactSubmission

class ContactAdmin(admin.ModelAdmin):
    # These names MUST match models.py exactly
    list_display = ('firstName', 'lastName', 'email', 'submitted_at')
    readonly_fields = ('firstName', 'lastName', 'email', 'phoneNumber', 'country', 'message', 'submitted_at')

admin.site.register(ContactSubmission, ContactAdmin)