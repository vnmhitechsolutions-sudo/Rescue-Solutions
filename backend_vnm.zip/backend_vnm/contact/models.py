from django.db import models

class ContactSubmission(models.Model):
    # Fields use camelCase to match React formData and Admin config
    firstName = models.CharField(max_length=100)
    lastName = models.CharField(max_length=100)
    email = models.EmailField()
    phoneNumber = models.CharField(max_length=20, blank=True)
    country = models.CharField(max_length=100, blank=True)
    message = models.TextField()
    
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.firstName} {self.lastName}"