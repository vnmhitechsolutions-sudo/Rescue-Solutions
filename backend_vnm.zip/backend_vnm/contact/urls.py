from django.urls import path
from .views import ContactCreateView

urlpatterns = [
    # Endpoint: http://127.0.0.1:8000/api/contact/submit/
    path('submit/', ContactCreateView.as_view(), name='contact-submit'),
]