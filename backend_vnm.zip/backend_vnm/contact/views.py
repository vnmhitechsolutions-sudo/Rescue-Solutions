from rest_framework import generics
from .models import ContactSubmission
from .serializers import ContactSerializer

# API View to handle contact form submissions (POST)
class ContactCreateView(generics.CreateAPIView):
    queryset = ContactSubmission.objects.all()
    serializer_class = ContactSerializer