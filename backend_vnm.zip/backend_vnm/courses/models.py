from django.db import models

class Course(models.Model):
    title = models.CharField(max_length=200)
    duration = models.CharField(max_length=50)
    mode = models.CharField(max_length=100) # e.g., "Online | Offline"
    details = models.JSONField(default=list) # The bullet points
    image = models.ImageField(upload_to='course_images/') 
    
    def __str__(self):
        return self.title

class CourseEnrollment(models.Model):
    name = models.CharField(max_length=200)
    email = models.EmailField()
    mobile = models.CharField(max_length=20)
    location = models.CharField(max_length=200)
    course_interested = models.CharField(max_length=200)
    linked_profile = models.URLField()
    message = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.course_interested}"