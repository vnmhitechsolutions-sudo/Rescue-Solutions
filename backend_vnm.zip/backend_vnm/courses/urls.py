from django.urls import path
from .views import CourseListView, EnrollmentCreateView

urlpatterns = [
    # Endpoint to get all courses (for the Courses.js grid)
    path('list/', CourseListView.as_view(), name='course-list'),
    
    # Endpoint to submit the enrollment form
    path('enroll/', EnrollmentCreateView.as_view(), name='course-enroll'),
]