from rest_framework import generics
from .models import Course, CourseEnrollment
from .serializers import CourseSerializer, EnrollmentSerializer

# API View to list all courses (GET)
class CourseListView(generics.ListAPIView):
    queryset = Course.objects.all()
    serializer_class = CourseSerializer

# API View to submit a new enrollment application (POST)
# The class name MUST be 'EnrollmentCreateView' to match your urls.py
class EnrollmentCreateView(generics.CreateAPIView):
    queryset = CourseEnrollment.objects.all()
    serializer_class = EnrollmentSerializer